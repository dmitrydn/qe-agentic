# Defect report: CYPRESS-RWA-USERS-008-negative-003

**Requirement:** CYPRESS-RWA-USERS-008
**Test case:** fails to create user without required password
**Confidence:** high

## Rationale
The API hints document that 'password' is a required field (any(must exist)) for POST /users. When the test omits the password field, the application should return 400 or 422 (client error indicating validation failure). Instead, the server returns 500 with a stack trace showing 'Error: Illegal arguments: undefined, string' in bcrypt.hashSync, indicating the backend attempts to hash an undefined password value rather than validating required fields first. This is a real defect: the application fails to validate required input before processing, resulting in an internal server error instead of proper client error response.

## Repro steps
1. Send POST /users with body containing firstName, lastName, username, balance, avatar, defaultPrivacyLevel but omitting password field
1. Observe response status 500 with bcrypt error 'Illegal arguments: undefined, string'
1. Expected: response status 400 or 422 indicating missing required field
